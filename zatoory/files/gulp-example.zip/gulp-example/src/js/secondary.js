console.log("I'm logging from the secondary.js file.");
console.log("Another log from secondary.js");