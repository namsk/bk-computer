const filename = "main.js";
console.log(`I'm logging from the ${filename} file.`);
console.log("Second Log from the main.js file.");