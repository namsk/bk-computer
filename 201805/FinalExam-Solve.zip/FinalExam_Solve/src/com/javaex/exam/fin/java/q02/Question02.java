package com.javaex.exam.fin.java.q02;

public class Question02 {
	public int getAnswer(int toNum) {
		//	TODO: 이곳에 해답을 작성합니다.
		int num = toNum;
		while (true) {
			boolean pass = true;
			for (int i = 1; i <= toNum; i++) {
				if (num % i != 0) {
					pass = false;
				}
			}
			if (pass) break;
			num++;
		}
		
		return num;
	}
}
