package com.javaex.exam.fin.java.q05;

public class Question05 {
	private int scores[];
	
	public Question05(int scores[]) {
		this.scores = scores;
	}
	
	public int getTotal() {
		//	TODO: 여기에 로직 코드를 작성합니다
		int total = 0;
		for (int score: scores) {
			if (score >= 0 && score <= 100) {
				total += score;
			}
		}
		return total;
	}
	
	public double getAverage() {
		//	TODO: 여기에 로직 코드를 작성합니다
		int total = 0, count = 0;
		for (int score:scores) {
			if (score >= 0 && score <= 100) {
				total += score;
				count++;
			}
		}
		return (double)total / count;
	}
}
