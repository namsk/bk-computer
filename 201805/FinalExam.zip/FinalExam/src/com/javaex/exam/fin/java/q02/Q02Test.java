package com.javaex.exam.fin.java.q02;

public class Q02Test {

	public static void main(String[] args) {
		//	Begin: 이 곳의 코드는 수정하지 않습니다.
		Question02 q2 = new Question02();
		System.out.println(q2.getAnswer(3));
		System.out.println(q2.getAnswer(10));
		//	End: 이 곳의 코드는 수정하지 않습니다.
	}

}
