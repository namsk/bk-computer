-- Q1.

SELECT last_name, salary, department_name 
FROM employees emp, departments dep
WHERE emp.department_id = dep.department_id (+) AND
    commission_pct is not null;

-- Q2.

SELECT emp.last_name, emp.salary, emp.job_id
FROM employees emp JOIN employees man
                    ON emp.manager_id = man.employee_id
WHERE man.last_name = 'King';


-- Q3.

SELECT emp.last_name, emp.salary
FROM employees emp, employees man
WHERE emp.manager_id = man.employee_id AND emp.salary > man.salary;

-- Q4.

SELECT min(salary), max(salary), sum(salary), round(avg(salary)) FROM employees;

-- Q5.

SELECT last_name, salary 
FROM employees emp
WHERE salary < (SELECT avg(salary)
                    FROM employees
                    WHERE department_id = emp.department_id);

