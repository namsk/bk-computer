def gugu(dan):
    print(dan, "단")
    print("----------")

    # 여기에 코드를 작성합니다
    for num in range(10):
        print(dan, "*", num, "=", dan * num)

# BEGIN: 점검을 위한 코드이니 수정하지 마십시오
gugu(3)
# END: 점검을 위한 코드이니 수정하지 마십시오

# 테스트를 위해 아래 주석을 해제하고 다른 값을 입력해 보셔도 좋습니다
# gugu(9)

